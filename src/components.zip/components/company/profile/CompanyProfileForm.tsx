import React, { useState } from 'react';
import { Building2, MapPin, Briefcase, Link as LinkIcon, Phone, Mail, FileText, CheckCircle2, ArrowRight, ArrowLeft, Building, Hash, Loader2, ImagePlus, X, Sparkles } from 'lucide-react';
import { AuthView } from '../../../types';
import { motion, AnimatePresence } from 'motion/react';
import { getFirebaseDb, getFirebaseAuth } from '../../../lib/firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';

interface Props {
  onNavigate: (view: AuthView) => void;
}

export function CompanyProfileForm({ onNavigate }: Props) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [serviceInput, setServiceInput] = useState('');
  const [services, setServices] = useState<string[]>([]);
  
  const [formData, setFormData] = useState({
    companyName: '',
    nip: '',
    description: '',
    address: '',
    city: '',
    postalCode: '',
    phone: '',
    email: '',
    website: '',
    socialLinks: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.id]: e.target.value });
  };

  const addService = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (serviceInput.trim() !== '' && !services.includes(serviceInput.trim())) {
        setServices([...services, serviceInput.trim()]);
      }
      setServiceInput('');
    }
  };

  const removeService = (serviceToRemove: string) => {
    setServices(services.filter(s => s !== serviceToRemove));
  };

  const validateStep = (currentStep: number): boolean => {
    setError(null);
    if (currentStep === 1) {
      if (!formData.companyName.trim()) {
        setError('Nazwa firmy jest wymagana.');
        return false;
      }
      if (formData.nip.trim() && !/^\d{10}$/.test(formData.nip.trim())) {
        setError('NIP musi składać się z dokładnie 10 cyfr.');
        return false;
      }
      if (!formData.description.trim() || formData.description.trim().length < 10) {
        setError('Opis firmy musi mieć co najmniej 10 znaków.');
        return false;
      }
    }
    if (currentStep === 2) {
      if (!formData.address.trim() || !formData.city.trim() || !formData.postalCode.trim()) {
        setError('Adres, miasto i kod pocztowy są wymagane.');
        return false;
      }
      if (formData.phone.trim() && !/^\+?[0-9\s-]{9,15}$/.test(formData.phone.trim())) {
        setError('Numer telefonu jest niepoprawny (wpisz od 9 do 15 cyfr).');
        return false;
      }
      if (formData.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
        setError('Podany adres e-mail jest niepoprawny.');
        return false;
      }
    }
    return true;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(prev => Math.min(prev + 1, 3));
    }
  };
  
  const handlePrev = () => {
    setError(null);
    setStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      handleNext();
    } else {
      if (!validateStep(1) || !validateStep(2)) return;
      if (services.length === 0) {
        setError('Wpisz przynajmniej jedną oferowaną usługę / kategorię w kroku 3.');
        return;
      }
      setLoading(true);
      setError(null);
      try {
        const auth = await getFirebaseAuth();
        const db = await getFirebaseDb();
        const user = auth.currentUser;
        if (!user) throw new Error("No user logged in");
        
        await setDoc(doc(db, 'companies', user.uid), {
          ...formData,
          services: services.join(', '),
          visibilityPackage: 'free',
          lat: 52.5360,
          lng: 17.5950,
          createdAt: serverTimestamp()
        });
        
        localStorage.setItem('has_company_profile_' + user.uid, 'true');
        console.log('Company Profile Submitted', formData);
        onNavigate('dashboard-company');
      } catch (err: any) {
        console.error('Error saving company profile:', err);
        setError(err.message || 'Failed to save profile');
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto font-sans">
      <div className="mb-10 text-center">
        <div className="w-11 h-11 bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-550/20 mx-auto mb-4 animate-pulse">
          <Sparkles className="w-5.5 h-5.5 text-white" />
        </div>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight leading-none">Profil Działalności</h1>
        <p className="text-xs font-semibold text-slate-500 mt-2">Uzupełnij informacje o firmie, aby założyć darmową wizytówkę.</p>
        
        {/* Progress Tracker */}
        <div className="mt-8 flex items-center justify-between relative max-w-sm mx-auto px-4">
          <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-0.5 bg-slate-200 z-0"></div>
          <motion.div 
            className="absolute left-0 top-1/2 -translate-y-1/2 h-0.5 bg-indigo-600 z-0" 
            initial={{ width: 0 }}
            animate={{ width: `${((step - 1) / 2) * 100}%` }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          ></motion.div>
          
          {[1, 2, 3].map((item) => (
            <motion.div 
              key={item} 
              initial={false}
              animate={{ 
                scale: step === item ? 1.05 : 1,
                backgroundColor: step >= item ? '#4f46e5' : '#ffffff',
                borderColor: step >= item ? '#4f46e5' : '#cbd5e1',
                color: step >= item ? '#ffffff' : '#64748b'
              }}
              className="relative z-15 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border shadow-xs transition-colors duration-300 bg-white"
            >
              {step > item ? <CheckCircle2 className="w-4.5 h-4.5" /> : item}
            </motion.div>
          ))}
        </div>
        <div className="flex justify-between text-[9px] font-bold text-slate-400 mt-3 uppercase tracking-wider max-w-sm mx-auto px-1">
          <span className={step >= 1 ? 'text-indigo-600' : ''}>Podstawowe</span>
          <span className={`text-center ${step >= 2 ? 'text-indigo-600' : ''}`}>Lokalizacja</span>
          <span className={`text-right ${step >= 3 ? 'text-indigo-600' : ''}`}>Usługi</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="relative">
        <AnimatePresence mode="wait">
          {error && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }} 
              animate={{ opacity: 1, height: 'auto' }} 
              exit={{ opacity: 0, height: 0 }}
              className="bg-rose-50 border border-rose-100/50 text-rose-700 p-4 rounded-xl text-xs font-semibold mb-6 flex items-center"
            >
              <span>{error}</span>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="space-y-6 animate-fadeIn"
            >
              <div className="bg-white border border-slate-200/60 shadow-xs p-6 sm:p-8 rounded-2xl space-y-5">
                <div className="flex items-center space-x-6 pb-6 border-b border-slate-100">
                  <div className="w-20 h-20 rounded-full bg-slate-50 border border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 hover:text-indigo-600 hover:border-indigo-300 hover:bg-indigo-50/20 transition-all cursor-pointer group shrink-0">
                    <ImagePlus className="w-5 h-5 mb-1 group-hover:scale-105 transition-transform" />
                    <span className="text-[8px] font-bold uppercase tracking-wider">Logo</span>
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">Tożsamość firmy</h3>
                    <p className="text-[11px] font-medium text-slate-500">Prześlij plik logo firmy oraz zdefiniuj podstawową markę działalności.</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label htmlFor="companyName" className="notion-label">Nazwa firmy</label>
                    <div className="relative group">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                        <Building className="h-4 w-4" />
                      </div>
                      <input
                        id="companyName"
                        type="text"
                        required
                        value={formData.companyName}
                        onChange={handleChange}
                        className="notion-input pl-9 bg-slate-50/50 border border-slate-200"
                        placeholder="np. Salon Anna Gniezno"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="nip" className="notion-label">NIP (Tax ID)</label>
                    <div className="relative group">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                        <Hash className="h-4 w-4" />
                      </div>
                      <input
                        id="nip"
                        type="text"
                        required
                        value={formData.nip}
                        onChange={handleChange}
                        className="notion-input pl-9 bg-slate-50/50 border border-slate-200"
                        placeholder="NIP np. 1234567890"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="description" className="notion-label font-black">O firmie (Opis)</label>
                    <div className="relative group">
                      <div className="absolute top-3.5 left-3 flex items-start pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                        <FileText className="h-4 w-4" />
                      </div>
                      <textarea
                        id="description"
                        required
                        rows={4}
                        value={formData.description}
                        onChange={handleChange}
                        className="notion-input pl-9 bg-slate-50/50 border border-slate-200 resize-none text-xs"
                        placeholder="Napisz kilka zdań o swojej firmie, usługach oraz doświadczeniu..."
                      />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="space-y-6 animate-fadeIn"
            >
              <div className="bg-white border border-slate-200/60 shadow-xs p-6 sm:p-8 rounded-2xl">
                <div className="mb-6 pb-4 border-b border-slate-100">
                  <h3 className="text-sm font-bold text-slate-900">Lokalizacja i kontakt</h3>
                  <p className="text-[11px] font-medium text-slate-500">Wpisz dane teleadresowe widoczne dla klientów.</p>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label htmlFor="address" className="notion-label">Ulica i numer</label>
                    <div className="relative group">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                        <MapPin className="h-4 w-4" />
                      </div>
                      <input
                        id="address"
                        type="text"
                        required
                        value={formData.address}
                        onChange={handleChange}
                        className="notion-input pl-9 bg-slate-50/50 border border-slate-200"
                        placeholder="np. Chrobrego 14/2"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="city" className="notion-label">Miasto</label>
                      <input
                        id="city"
                        type="text"
                        required
                        value={formData.city}
                        onChange={handleChange}
                        className="notion-input bg-slate-50/50 border border-slate-200"
                        placeholder="np. Gniezno"
                      />
                    </div>
                    <div>
                      <label htmlFor="postalCode" className="notion-label">Kod pocztowy</label>
                      <input
                        id="postalCode"
                        type="text"
                        required
                        value={formData.postalCode}
                        onChange={handleChange}
                        className="notion-input bg-slate-50/50 border border-slate-200"
                        placeholder="np. 62-200"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
                    <div>
                      <label htmlFor="phone" className="notion-label">Telefon</label>
                      <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                          <Phone className="h-4 w-4" />
                        </div>
                        <input
                          id="phone"
                          type="tel"
                          required
                          value={formData.phone}
                          onChange={handleChange}
                          className="notion-input pl-9 bg-slate-50/50 border border-slate-200"
                          placeholder="+48 123 456 789"
                        />
                      </div>
                    </div>
                    <div>
                      <label htmlFor="email" className="notion-label">E-mail biznesowy</label>
                      <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                          <Mail className="h-4 w-4" />
                        </div>
                        <input
                          id="email"
                          type="email"
                          required
                          value={formData.email}
                          onChange={handleChange}
                          className="notion-input pl-9 bg-slate-50/50 border border-slate-200"
                          placeholder="kontakt@example.pl"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="space-y-6 animate-fadeIn"
            >
              <div className="bg-white border border-slate-200/60 shadow-xs p-6 sm:p-8 rounded-2xl">
                <div className="mb-6 pb-4 border-b border-slate-100">
                  <h3 className="text-sm font-bold text-slate-900">Słowa kluczowe i strona www</h3>
                  <p className="text-[11px] font-medium text-slate-500">Zdefiniuj kategorie oraz adresy www.</p>
                </div>
                
                <div className="space-y-5">
                  <div>
                    <label className="notion-label">Słowa kluczowe / Usługi (Wpisz i zatwierdź Enterem)</label>
                    <div className="relative group mb-3.5">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                        <Briefcase className="h-4 w-4" />
                      </div>
                      <input
                        type="text"
                        value={serviceInput}
                        onChange={(e) => setServiceInput(e.target.value)}
                        onKeyDown={addService}
                        className="notion-input pl-9 bg-slate-50/50 border border-slate-200"
                        placeholder="np. Strzyżenie męskie"
                      />
                    </div>
                    
                    <div className="flex flex-wrap gap-1.5">
                      <AnimatePresence>
                        {services.map((service) => (
                          <motion.span
                            key={service}
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            className="inline-flex items-center px-2.5 py-1 rounded-lg bg-indigo-50 border border-indigo-100/50 text-indigo-700 text-xs font-semibold shadow-3xs"
                          >
                            {service}
                            <button
                              type="button"
                              onClick={() => removeService(service)}
                              className="ml-1.5 text-indigo-400 hover:text-indigo-600 focus:outline-none cursor-pointer"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </motion.span>
                        ))}
                      </AnimatePresence>
                      {services.length === 0 && (
                        <span className="text-xs text-slate-400 italic">Nie dodano jeszcze żadnych słów kluczowych.</span>
                      )}
                    </div>
                  </div>
                  
                  <div className="pt-6 border-t border-slate-100 space-y-4">
                    <div>
                      <label htmlFor="website" className="notion-label">Strona WWW (opcjonalnie)</label>
                      <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                          <LinkIcon className="h-4 w-4" />
                        </div>
                        <input
                          id="website"
                          type="url"
                          value={formData.website}
                          onChange={handleChange}
                          className="notion-input pl-9 bg-slate-50/50 border border-slate-200"
                          placeholder="https://example.pl"
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="socialLinks" className="notion-label">Link do profilu społecznościowego (opcjonalnie)</label>
                      <div className="relative group">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
                          <LinkIcon className="h-4 w-4" />
                        </div>
                        <input
                          id="socialLinks"
                          type="text"
                          value={formData.socialLinks}
                          onChange={handleChange}
                          className="notion-input pl-9 bg-slate-50/50 border border-slate-200"
                          placeholder="facebook.com/twoja_firma"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center justify-between pt-6 mt-2">
          {step > 1 ? (
            <button
              type="button"
              onClick={handlePrev}
              className="flex items-center px-5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-slate-900 focus:outline-none transition-all cursor-pointer shadow-3xs"
            >
              <ArrowLeft className="w-3.5 h-3.5 mr-1.5" />
              Wstecz
            </button>
          ) : (
            <div></div>
          )}
          
          <button
            type="submit"
            disabled={loading}
            className="group relative flex items-center px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold focus:outline-none transition-all shadow-md shadow-indigo-600/10 disabled:opacity-70 disabled:cursor-not-allowed cursor-pointer"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : (step === 3 ? 'Zatwierdź profil' : 'Dalej')}
            {step < 3 && <ArrowRight className="w-3.5 h-3.5 ml-1.5 group-hover:translate-x-0.5 transition-transform" />}
          </button>
        </div>
      </form>
    </div>
  );
}
