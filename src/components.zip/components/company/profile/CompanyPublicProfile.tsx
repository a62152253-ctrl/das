import React, { useState, useEffect } from 'react';
import { 
  MapPin, Star, Building2, Phone, Mail, Globe, Loader2, 
  ExternalLink, Calendar, Facebook, Instagram, Video, Award, 
  ShieldCheck, Check, Copy, ChevronDown, ChevronUp, Clock, 
  CreditCard, Sparkles, MessageSquare, Info, Send, CheckCircle2
} from 'lucide-react';
import { Company, Service, Promotion } from '@/types';
import { fetchSearchData } from '../../../lib/SearchEngine';
import { useAuth } from '../../../lib/AuthContext';
import { getFirebaseDb } from '../../../lib/firebase';
import { collection, addDoc } from 'firebase/firestore';
import { Skeleton, Button, Badge } from '@/ui';

interface Props {
  companyId: string;
  onBack: () => void;
  onContact: (companyId: string, companyName: string) => void;
}

export function CompanyPublicProfile({ companyId, onBack, onContact }: Props) {
  const { user } = useAuth();
  const [company, setCompany] = useState<Company | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [openFaqIdx, setOpenFaqIdx] = useState<number | null>(null);
  
  // Interactive Booking Widget State
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState('');
  const [bookingStep, setBookingStep] = useState<'idle' | 'form' | 'confirmed'>('idle');
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');

  // Review Filtering State
  const [ratingFilter, setRatingFilter] = useState<number | 'all'>('all');

  const timeSlots = ['09:00', '10:30', '12:00', '13:30', '15:00', '16:30'];

  useEffect(() => {
    async function loadCompanyData() {
      try {
        const { companies, services: allServices, promotions: allPromos } = await fetchSearchData();
        const found = companies.find(c => c.uid === companyId);
        if (found) {
          setCompany(found);
          setServices(allServices.filter(s => s.companyId === companyId && s.isActive !== false));
          setPromotions(allPromos.filter(p => p.companyId === companyId && p.isActive !== false));
        }
      } catch (err) {
        console.error("Error loading company profile", err);
      } finally {
        setLoading(false);
      }
    }
    loadCompanyData();
  }, [companyId]);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService || !selectedDate || !selectedTimeSlot || !clientName || !clientPhone || !company) return;

    try {
      const db = await getFirebaseDb();
      await addDoc(collection(db, 'bookings'), {
        companyId,
        companyName: company.companyName,
        clientId: user?.uid || 'guest',
        clientName,
        clientPhone,
        serviceName: selectedService.name,
        price: selectedService.price,
        date: selectedDate,
        time: selectedTimeSlot,
        status: 'pending',
        createdAt: new Date().toISOString()
      });

      await addDoc(collection(db, 'notifications'), {
        userId: companyId,
        title: 'Nowa rezerwacja',
        content: `Klient ${clientName} poprosił o rezerwację na ${selectedService.name} w dniu ${selectedDate} o ${selectedTimeSlot}.`,
        read: false,
        createdAt: new Date().toISOString(),
        type: 'system'
      });

      setBookingStep('confirmed');
    } catch (err) {
      console.error('Failed to submit booking to Firestore:', err);
    }
  };

  const checkIsOpenNow = () => {
    if (!company?.openingHours) return { status: 'unknown', text: 'Brak godzin' };
    const daysMap: Record<number, string> = {
      0: 'Niedziela', 1: 'Poniedziałek', 2: 'Wtorek', 3: 'Środa', 4: 'Czwartek', 5: 'Piątek', 6: 'Sobota'
    };
    const now = new Date();
    const currentDayName = daysMap[now.getDay()];
    const hoursStr = company.openingHours[currentDayName];

    if (!hoursStr || hoursStr.toLowerCase().includes('zamknięte')) {
      return { status: 'closed', text: 'Zamknięte dzisiaj' };
    }

    const match = hoursStr.match(/(\d{2}):(\d{2})\s*-\s*(\d{2}):(\d{2})/);
    if (!match) return { status: 'open', text: hoursStr };

    const startHour = parseInt(match[1]);
    const startMin = parseInt(match[2]);
    const endHour = parseInt(match[3]);
    const endMin = parseInt(match[4]);

    const currentHour = now.getHours();
    const currentMin = now.getMinutes();

    const startTotal = startHour * 60 + startMin;
    const endTotal = endHour * 60 + endMin;
    const currentTotal = currentHour * 60 + currentMin;

    if (currentTotal >= startTotal && currentTotal < endTotal) {
      return { status: 'open', text: `Otwarte dzisiaj (do ${match[3]}:${match[4]})` };
    }
    return { status: 'closed', text: `Zamknięte (otwarcie o ${match[1]}:${match[2]})` };
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-32 space-y-4">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest animate-pulse">Ładowanie wizytówki...</p>
      </div>
    );
  }

  if (!company) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center font-sans">
        <h2 className="text-2xl font-black text-slate-900 mb-4">Nie znaleziono firmy</h2>
        <button onClick={onBack} className="text-indigo-600 hover:underline font-bold">Wróć do wyszukiwarki</button>
      </div>
    );
  }

  const openStatus = checkIsOpenNow();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 font-sans bg-[#f8f8f7] min-h-screen">
      <button 
        onClick={onBack}
        className="mb-6 font-bold text-xs text-slate-500 hover:text-indigo-600 transition-colors flex items-center gap-1 cursor-pointer"
      >
        ← Powrót do wyników
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Visual details, services list, promotions, FAQ */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Header Card */}
          <div className="bg-white rounded-2xl border border-slate-200/60 overflow-hidden shadow-2xs">
            <div className="h-60 bg-slate-900 relative overflow-hidden">
              {company.mainPhoto ? (
                <img 
                  src={company.mainPhoto} 
                  alt={company.companyName} 
                  className="w-full h-full object-cover opacity-70"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-indigo-900 via-slate-900 to-indigo-950 flex items-center justify-center">
                  <Sparkles className="w-12 h-12 text-indigo-400/20" />
                </div>
              )}
              {/* Floating packages badge */}
              {company.visibilityPackage !== 'free' && (
                <span className="absolute top-4 right-4 bg-indigo-600 text-white text-[9px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full shadow-md animate-pulse">
                  PREMIUM PARTNER
                </span>
              )}
            </div>

            <div className="px-6 md:px-8 pb-8 relative">
              <div className="w-20 h-20 bg-white rounded-2xl p-1 shadow-lg absolute -top-10 border border-slate-100/80 flex items-center justify-center">
                <div className="w-full h-full bg-slate-50 rounded-xl overflow-hidden flex items-center justify-center">
                  {company.logo ? (
                    <img src={company.logo} alt="logo" className="w-full h-full object-cover" />
                  ) : (
                    <Building2 className="w-8 h-8 text-slate-400" />
                  )}
                </div>
              </div>

              <div className="pt-14">
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                  <div>
                    <h2 className="text-2xl font-black text-slate-900 tracking-tight leading-tight">{company.companyName}</h2>
                    <div className="flex flex-wrap gap-3 items-center mt-2 text-slate-500 font-semibold text-[11px]">
                      <p className="flex items-center">
                        <MapPin className="w-3.5 h-3.5 mr-1 text-slate-400" />
                        {company.address}, {company.city}
                      </p>
                      {company.foundedYear && (
                        <p className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 font-bold">
                          Na rynku od {company.foundedYear} r.
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-700 rounded-full border border-amber-250/50 text-xs font-bold self-start shrink-0">
                    <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                    <span>{company.rating || 5.0} ({company.reviewCount || 0} opinii)</span>
                  </div>
                </div>

                {/* Team photo section */}
                {company.teamPhoto && (
                  <div className="my-6 border border-slate-200/50 rounded-2xl overflow-hidden bg-slate-50/50 shadow-3xs">
                    <div className="h-44 relative">
                      <img src={company.teamPhoto} alt="Nasz zespół" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-900/30 to-transparent flex flex-col justify-end p-4">
                        <p className="text-white text-xs font-black uppercase tracking-wider flex items-center gap-1">
                          <Award className="w-4 h-4 text-indigo-400" />
                          Poznaj nasz zespół
                        </p>
                        <p className="text-slate-300 text-[10px] font-semibold mt-0.5">Doświadczeni certyfikowani specjaliści, którzy dbają o najwyższą jakość usług.</p>
                      </div>
                    </div>
                  </div>
                )}

                <div className="border-t border-slate-100 pt-5">
                  <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">O firmie</h3>
                  <p className="text-slate-700 leading-relaxed font-semibold text-xs whitespace-pre-line">
                    {company.description}
                  </p>
                </div>

                {/* Amenities & Payment Methods */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6 pt-5 border-t border-slate-100">
                  {company.amenities && company.amenities.length > 0 && (
                    <div>
                      <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Udogodnienia w lokalu</h4>
                      <div className="flex flex-wrap gap-1.5">
                        {company.amenities.map(amenity => (
                          <span key={amenity} className="flex items-center gap-1 px-2.5 py-1 bg-slate-50 border border-slate-200/40 text-slate-600 text-[10px] font-bold rounded-lg shadow-3xs">
                            <Check className="w-3 h-3 text-emerald-500" />
                            {amenity}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {company.paymentMethods && company.paymentMethods.length > 0 && (
                    <div>
                      <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Metody płatności</h4>
                      <div className="flex flex-wrap gap-1.5">
                        {company.paymentMethods.map(pay => (
                          <span key={pay} className="flex items-center gap-1 px-2.5 py-1 bg-slate-50 border border-slate-200/40 text-slate-600 text-[10px] font-bold rounded-lg shadow-3xs">
                            <CreditCard className="w-3 h-3 text-indigo-500" />
                            {pay}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Active Promotions */}
          {promotions.length > 0 && (
            <div className="bg-white rounded-2xl border border-slate-200/60 p-6 md:p-8 shadow-2xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Sparkles className="w-4.5 h-4.5 text-indigo-600" />
                Aktualne okazje i kupony rabatowe
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {promotions.map(promo => (
                  <div key={promo.id} className="p-4 bg-slate-50 border border-indigo-100/40 rounded-xl flex flex-col justify-between relative overflow-hidden shadow-3xs">
                    <div className="absolute -right-3 -top-3 w-10 h-10 bg-red-100 rounded-full flex items-center justify-center transform rotate-12">
                      <span className="text-[9px] font-black text-red-700">%</span>
                    </div>
                    <div>
                      <div className="bg-red-50 text-red-750 text-[10px] font-bold px-2 py-0.5 rounded-md w-fit mb-2">
                        {promo.discountValue}
                      </div>
                      <h4 className="font-bold text-slate-900 text-xs">{promo.title}</h4>
                      <p className="text-[10px] text-slate-500 font-semibold mt-1 leading-normal">{promo.description}</p>
                    </div>
                    
                    {promo.promoCode && (
                      <div className="mt-4 flex items-center justify-between bg-white border border-slate-200/60 p-2 rounded-lg">
                        <span className="text-[9px] font-bold text-slate-400">Kod: <span className="font-extrabold text-slate-800">{promo.promoCode}</span></span>
                        <button
                          onClick={() => handleCopyCode(promo.promoCode || '')}
                          className="flex items-center gap-1 text-[9px] font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer"
                        >
                          {copiedCode === promo.promoCode ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-500" />
                              Skopiowano
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              Kopiuj
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Realization Gallery */}
          {company.gallery && company.gallery.length > 0 && (
            <div className="bg-white rounded-2xl border border-slate-200/60 p-6 md:p-8 shadow-2xs">
              <h3 className="text-sm font-bold text-slate-900 mb-4">Galeria realizacji</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {company.gallery.map((img, idx) => (
                  <div key={idx} className="h-32 bg-slate-100 rounded-xl overflow-hidden shadow-3xs hover:scale-[1.02] transition-transform">
                    <img src={img} alt="realizacja" className="w-full h-full object-cover animate-fadeIn" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Services list & booking selectors */}
          <div className="bg-white rounded-2xl border border-slate-200/60 p-6 md:p-8 shadow-2xs">
            <h3 className="text-sm font-bold text-slate-900 mb-4">Oferta i cennik</h3>
            <div className="space-y-4">
              {services.length > 0 ? (
                services.map(s => (
                  <div 
                    key={s.id} 
                    className="flex justify-between items-start py-4 border-b border-slate-100 last:border-0 hover:bg-slate-50/50 -mx-4 px-4 rounded-xl transition-all cursor-pointer group"
                    onClick={() => {
                      setSelectedService(s);
                      setBookingStep('form');
                    }}
                  >
                    <div className="pr-4">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-indigo-50/50 text-indigo-600">{s.category || 'Inne'}</span>
                        {s.durationMin && (
                          <span className="text-[9px] font-bold text-slate-400 flex items-center gap-0.5">
                            <Clock className="w-3 h-3 text-slate-400" />
                            {s.durationMin} min
                          </span>
                        )}
                      </div>
                      <span className="font-bold text-slate-900 text-xs block group-hover:text-indigo-600 transition-colors">{s.name}</span>
                      {s.description && <span className="text-[10px] text-slate-400 font-semibold block mt-1 leading-normal">{s.description}</span>}
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="font-extrabold text-slate-900 text-xs">{s.price} zł</span>
                      <button className="text-[9px] font-bold text-indigo-600 bg-indigo-50 border border-indigo-100/50 px-2 py-1 rounded hover:bg-indigo-600 hover:text-white transition-all">
                        Wybierz
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                company.services ? (
                  company.services.split(',').filter(Boolean).map((serv, idx) => (
                    <div key={idx} className="flex justify-between items-center py-3 border-b border-slate-100 last:border-0">
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full" />
                        <span className="font-bold text-slate-800 text-xs">{serv.trim()}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-500 text-xs font-semibold">Ta firma nie zdefiniowała jeszcze szczegółowej oferty.</p>
                )
              )}
            </div>
          </div>

          {/* FAQs */}
          {company.faqs && company.faqs.length > 0 && (
            <div className="bg-white rounded-2xl border border-slate-200/60 p-6 md:p-8 shadow-2xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Info className="w-4.5 h-4.5 text-indigo-600" />
                Często zadawane pytania (FAQ)
              </h3>
              <div className="space-y-3">
                {company.faqs.map((faq, index) => {
                  const isOpen = openFaqIdx === index;
                  return (
                    <div key={index} className="border border-slate-150 rounded-xl overflow-hidden transition-all bg-slate-50/20">
                      <button
                        onClick={() => setOpenFaqIdx(isOpen ? null : index)}
                        className="w-full flex justify-between items-center p-3 text-left font-bold text-slate-800 text-xs hover:bg-slate-50 transition-colors cursor-pointer"
                      >
                        <span>{faq.question}</span>
                        {isOpen ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                      </button>
                      {isOpen && (
                        <div className="p-3 pt-0 border-t border-slate-100 text-[11px] font-semibold text-slate-500 leading-relaxed bg-white">
                          {faq.answer}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Sticky contact / reservation sidebar & location */}
        <div className="space-y-6">
          
          {/* Reservation Widget */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200/60 shadow-2xs space-y-6">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">Kontakt i Rezerwacja</h3>

            {/* Open / Closed tag */}
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full shrink-0 ${openStatus.status === 'open' ? 'bg-emerald-500 animate-pulse' : 'bg-red-400'}`} />
              <span className="text-[11px] font-bold text-slate-700">{openStatus.text}</span>
            </div>

            {/* INTERACTIVE BOOKING PREVIEW */}
            {bookingStep === 'idle' && (
              <div className="space-y-3">
                <button
                  onClick={() => {
                    if (services.length > 0) setSelectedService(services[0]);
                    setBookingStep('form');
                  }}
                  className="w-full flex items-center justify-center gap-1.5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md shadow-indigo-600/10 hover:shadow-lg transition-all text-xs cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  Zarezerwuj wizytę
                </button>
                <button 
                  onClick={() => onContact(company.uid, company.companyName)}
                  className="w-full py-2.5 bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-800 font-bold rounded-xl transition-all cursor-pointer text-xs"
                >
                  Napisz wiadomość
                </button>
              </div>
            )}

            {bookingStep === 'form' && (
              <form onSubmit={handleBookingSubmit} className="space-y-4 text-left border-t border-slate-100 pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">Nowa rezerwacja</span>
                  <button 
                    type="button" 
                    onClick={() => setBookingStep('idle')} 
                    className="text-[9px] font-bold text-slate-400 hover:underline"
                  >
                    Anuluj
                  </button>
                </div>

                <div>
                  <label className="notion-label">Wybrana usługa</label>
                  <select
                    value={selectedService?.id || ''}
                    onChange={(e) => {
                      const found = services.find(s => s.id === e.target.value);
                      if (found) setSelectedService(found);
                    }}
                    className="notion-input bg-white border border-slate-200/70"
                  >
                    {services.map(s => (
                      <option key={s.id} value={s.id}>{s.name} ({s.price} zł)</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="notion-label">Data</label>
                    <input 
                      type="date" 
                      required
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      className="notion-input bg-white border border-slate-200/70" 
                    />
                  </div>
                  <div>
                    <label className="notion-label">Godzina</label>
                    <select
                      value={selectedTimeSlot}
                      onChange={(e) => setSelectedTimeSlot(e.target.value)}
                      required
                      className="notion-input bg-white border border-slate-200/70"
                    >
                      <option value="">Wybierz...</option>
                      {timeSlots.map(t => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="notion-label">Twoje imię i nazwisko</label>
                  <input 
                    type="text" 
                    required 
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder="Jan Kowalski" 
                    className="notion-input bg-white border border-slate-200/70" 
                  />
                </div>

                <div>
                  <label className="notion-label">Numer telefonu</label>
                  <input 
                    type="tel" 
                    required
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    placeholder="123456789" 
                    className="notion-input bg-white border border-slate-200/70" 
                  />
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-1.5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg transition-all text-xs cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  Wyślij zgłoszenie
                </button>
              </form>
            )}

            {bookingStep === 'confirmed' && (
              <div className="p-4 bg-indigo-50/50 border border-indigo-100 rounded-2xl text-center space-y-3">
                <CheckCircle2 className="w-8 h-8 text-indigo-600 mx-auto" />
                <h4 className="font-bold text-indigo-950 text-xs">Rezerwacja wysłana!</h4>
                <p className="text-[10px] text-indigo-800 leading-normal font-semibold">
                  Twoje zapytanie rezerwacyjne na usługę <span className="font-bold">{selectedService?.name}</span> na dzień <span className="font-bold">{selectedDate} o {selectedTimeSlot}</span> zostało przesłane do salonu.
                </p>
                <button
                  onClick={() => setBookingStep('idle')}
                  className="text-[9px] font-bold text-indigo-600 hover:underline"
                >
                  Zamknij
                </button>
              </div>
            )}

            {/* Direct details info */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                <div>
                  <span className="text-[9px] font-bold text-slate-400 block uppercase tracking-wider">Telefon kontaktowy</span>
                  <span className="font-bold text-slate-800 text-xs">{company.phone}</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                <div>
                  <span className="text-[9px] font-bold text-slate-400 block uppercase tracking-wider">E-mail</span>
                  <span className="font-bold text-slate-800 text-xs">{company.email}</span>
                </div>
              </div>

              {company.website && (
                <div className="flex items-center gap-3">
                  <Globe className="w-4 h-4 text-slate-400 shrink-0" />
                  <div>
                    <span className="text-[9px] font-bold text-slate-400 block uppercase tracking-wider">Strona WWW</span>
                    <a href={company.website} target="_blank" rel="noopener noreferrer" className="font-bold text-indigo-600 hover:underline text-xs flex items-center gap-0.5">
                      {company.website.replace(/^https?:\/\//, '')}
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              )}
            </div>

            {/* Social media links */}
            {(company.facebook || company.instagram || company.tiktok) && (
              <div className="border-t border-slate-100 pt-4">
                <span className="text-[9px] font-bold text-slate-400 block uppercase mb-2 tracking-wider">Media Społecznościowe</span>
                <div className="flex gap-2">
                  {company.facebook && (
                    <a href={company.facebook} target="_blank" rel="noopener noreferrer" className="p-2 bg-slate-50 border border-slate-200/50 rounded-lg hover:bg-indigo-50 hover:text-indigo-600 text-slate-500 transition-all cursor-pointer" title="Facebook">
                      <Facebook className="w-4 h-4" />
                    </a>
                  )}
                  {company.instagram && (
                    <a href={company.instagram} target="_blank" rel="noopener noreferrer" className="p-2 bg-slate-50 border border-slate-200/50 rounded-lg hover:bg-indigo-50 hover:text-indigo-600 text-slate-500 transition-all cursor-pointer" title="Instagram">
                      <Instagram className="w-4 h-4" />
                    </a>
                  )}
                  {company.tiktok && (
                    <a href={company.tiktok} target="_blank" rel="noopener noreferrer" className="p-2 bg-slate-50 border border-slate-200/50 rounded-lg hover:bg-indigo-50 hover:text-indigo-600 text-slate-500 transition-all cursor-pointer" title="TikTok">
                      <Video className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Certifications Box */}
          {company.certificates && company.certificates.length > 0 && (
            <div className="bg-white rounded-2xl p-6 border border-slate-200/60 shadow-2xs space-y-4">
              <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-indigo-600" />
                Certyfikaty i Weryfikacja
              </h3>
              <div className="space-y-2.5">
                {company.certificates.map((cert, idx) => (
                  <div key={idx} className="flex gap-2 items-start p-2.5 bg-slate-50 rounded-lg border border-slate-200/40 shadow-3xs">
                    <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <span className="text-[11px] font-bold text-slate-700 leading-snug">{cert}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Hours list */}
          {company.openingHours && Object.keys(company.openingHours).length > 0 && (
            <div className="bg-white rounded-2xl p-6 border border-slate-200/60 shadow-2xs">
              <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3 mb-4 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-slate-400" />
                Godziny otwarcia
              </h3>
              <div className="space-y-2">
                {Object.entries(company.openingHours).map(([days, hours]) => {
                  const daysMap: Record<number, string> = {
                    0: 'Niedziela', 1: 'Poniedziałek', 2: 'Wtorek', 3: 'Środa', 4: 'Czwartek', 5: 'Piątek', 6: 'Sobota'
                  };
                  const isToday = days === daysMap[new Date().getDay()];
                  return (
                    <div key={days} className={`flex justify-between text-xs font-semibold p-1.5 rounded-lg ${isToday ? 'bg-indigo-50/50 text-indigo-700 border border-indigo-100/50 font-black' : 'text-slate-500'}`}>
                      <span>{days}</span>
                      <span className="font-extrabold">{hours as string}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
