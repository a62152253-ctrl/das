import React, { useState, useEffect } from 'react';
import { Company, Statistics } from '../../../types';
import { Eye, PhoneCall, MessageSquare, Star, Sparkles, TrendingUp, Users, CheckCircle2, AlertCircle, ArrowUpRight, Award, Download, Calendar, Zap, TrendingDown, BarChart3, Filter, X, Moon, Sun } from 'lucide-react';
import { getFirebaseDb } from '../../../lib/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';

interface Props {
  company: Company;
  stats: Statistics | null;
}

interface DailyStats {
  date: string;
  views: number;
  searches: number;
  phones: number;
  messages: number;
}

export function CompanyStatistics({ company, stats }: Props) {
  const [darkMode, setDarkMode] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState<'7d' | '30d' | '90d'>('30d');
  const [dailyStats, setDailyStats] = useState<DailyStats[]>([]);
  const [loading, setLoading] = useState(false);
  const [showTrendForecast, setShowTrendForecast] = useState(false);

  // ✨ Firebase Real-time Data Fetch
  useEffect(() => {
    const loadHistoricalData = async () => {
      if (!company.uid) return;
      setLoading(true);
      try {
        const db = await getFirebaseDb();
        const statsRef = collection(db, 'statistics');
        const q = query(statsRef, where('companyId', '==', company.uid));
        const docs = await getDocs(q);
        
        const data = docs.docs.map(doc => doc.data() as DailyStats);
        setDailyStats(data.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
      } catch (err) {
        console.error('Error loading statistics:', err);
      } finally {
        setLoading(false);
      }
    };
    loadHistoricalData();
  }, [company.uid]);

  // ✨ Trend Forecast (simple linear regression)
  const calculateForecast = () => {
    if (dailyStats.length < 2) return null;
    const recentData = dailyStats.slice(-7);
    const avgViews = recentData.reduce((acc, d) => acc + d.views, 0) / recentData.length;
    const trend = (recentData[recentData.length - 1].views - recentData[0].views) / recentData.length;
    return {
      nextWeekViews: Math.max(0, Math.round(avgViews + trend * 7)),
      trend: trend > 0 ? 'up' : 'down',
      percentage: Math.abs(Math.round((trend / avgViews) * 100))
    };
  };

  // ✨ Compare with Previous Month
  const getPreviousPeriodComparison = () => {
    if (!stats) return { change: 0, percent: 0 };
    const average = Math.round((stats.views + stats.searches + stats.phones + stats.messages) / 4);
    const prevAverage = stats.previousMonth?.views || 0;
    const change = average - prevAverage;
    const percent = prevAverage ? Math.round((change / prevAverage) * 100) : 0;
    return { change, percent };
  };

  // ✨ Export PDF Function
  const handleExportPDF = () => {
    const content = `
RAPORT STATYSTYK FIRMY - ${company.companyName}
Okres: ${selectedPeriod === '7d' ? 'Ostatnie 7 dni' : selectedPeriod === '30d' ? 'Ostatnie 30 dni' : 'Ostatnie 90 dni'}

METRYKI GŁÓWNE:
- Wyświetlenia: ${stats?.views || 0}
- Wyszukiwania: ${stats?.searches || 0}
- Kliknięcia telefonu: ${stats?.phones || 0}
- Wiadomości: ${stats?.messages || 0}

PORÓWNANIE Z POPRZEDNIM OKRESEM:
- Zmiana: ${getPreviousPeriodComparison().change > 0 ? '+' : ''}${getPreviousPeriodComparison().change}
- Wzrost procentowy: ${getPreviousPeriodComparison().percent}%

PROGNOZA:
${calculateForecast() ? `- Przewidywane wyświetlenia za tydzień: ${calculateForecast()?.nextWeekViews}` : 'Brak danych'}
    `.trim();
    
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', `statystyki-${company.companyName}-${new Date().toISOString().split('T')[0]}.txt`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const forecast = calculateForecast();
  const comparison = getPreviousPeriodComparison();
  const completenessItems = [
    { label: 'Nazwa i miasto', done: !!(company.companyName && company.city) },
    { label: 'Numer telefonu', done: !!company.phone },
    { label: 'Opis działalności', done: !!(company.description && company.description.length >= 30) },
    { label: 'Zdjęcie główne', done: !!(company.logo || company.mainPhoto) },
  ];

  return (
    <div className={`space-y-10 font-sans transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-50' : 'bg-white'}`}>
      {/* ✨ Dark Mode Toggle + Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b" style={{ borderColor: darkMode ? '#1e293b' : '#e2e8f0' }} >
        <div className="pb-6 md:pb-0">
          <h3 className={`text-xl font-bold tracking-tight ${darkMode ? 'text-slate-50' : 'text-slate-900'}`}>Witaj w panelu statystyk</h3>
          <p className={`text-xs font-semibold mt-1 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Pozycjonowanie Twojej wizytówki w lokalnej wyszukiwarce LOKALNIE PRO.
          </p>
        </div>

        <div className="flex items-center gap-3 pb-6 md:pb-0">
          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`p-2 rounded-lg transition-colors ${
              darkMode 
                ? 'bg-slate-800 text-yellow-400 hover:bg-slate-700' 
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>

          {/* ✨ Period Filter */}
          <div className="flex gap-1 rounded-lg border p-1" style={{ borderColor: darkMode ? '#334155' : '#e2e8f0', backgroundColor: darkMode ? '#1e293b' : '#f8fafc' }}>
            {(['7d', '30d', '90d'] as const).map(period => (
              <button
                key={period}
                onClick={() => setSelectedPeriod(period)}
                className={`px-3 py-1 rounded text-xs font-bold transition-all ${
                  selectedPeriod === period
                    ? 'bg-indigo-600 text-white shadow-md'
                    : darkMode ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {period === '7d' ? '7 dni' : period === '30d' ? '30 dni' : '90 dni'}
              </button>
            ))}
          </div>

          {/* ✨ Export PDF */}
          <button
            onClick={handleExportPDF}
            className="flex items-center gap-2 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs transition-all shadow-md"
          >
            <Download className="w-4 h-4" />
            Eksport PDF
          </button>
        </div>
      </div>

      {/* ✨ KPI Cards Grid with Comparisons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Wyświetlenia wizytówki', val: stats?.views ?? 0, icon: Eye, color: darkMode ? 'text-blue-400 bg-blue-950' : 'text-blue-500 bg-blue-50', change: comparison.percent },
          { label: 'Zapytania w wyszukiwarce', val: stats?.searches ?? 0, icon: Users, color: darkMode ? 'text-emerald-400 bg-emerald-950' : 'text-emerald-500 bg-emerald-50', change: comparison.percent },
          { label: 'Wybrane numery tel.', val: stats?.phones ?? 0, icon: PhoneCall, color: darkMode ? 'text-amber-400 bg-amber-950' : 'text-amber-500 bg-amber-50', change: comparison.percent },
          { label: 'Rozpoczęte czaty', val: stats?.messages ?? 0, icon: MessageSquare, color: darkMode ? 'text-indigo-400 bg-indigo-950' : 'text-indigo-500 bg-indigo-50', change: comparison.percent },
        ].map((kpi, idx) => (
          <div key={idx} className={`p-6 border rounded-xl transition-all ${
            darkMode 
              ? 'bg-slate-900 border-slate-800 hover:border-slate-700' 
              : 'bg-white border-slate-200/60 hover:border-slate-300/60'
          }`}>
            <div className="flex justify-between items-start mb-4">
              <span className={`text-[10px] font-bold uppercase tracking-widest ${darkMode ? 'text-slate-400' : 'text-slate-400'}`}>{kpi.label}</span>
              <div className={`p-2 rounded-lg border ${kpi.color} bg-opacity-20`}>
                <kpi.icon className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <p className={`text-2xl font-extrabold tracking-tight ${darkMode ? 'text-slate-50' : 'text-slate-900'}`}>{kpi.val.toLocaleString('pl-PL')}</p>
              <span className={`text-[10px] font-bold flex items-center px-1.5 py-0.5 rounded ${
                kpi.change >= 0 
                  ? 'bg-emerald-50 text-emerald-600'
                  : darkMode ? 'bg-red-950 text-red-400' : 'bg-red-50 text-red-600'
              }`}>
                {kpi.change >= 0 ? <ArrowUpRight className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
                {Math.abs(kpi.change)}%
              </span>
            </div>
          </div>
        ))}
      </div>

      {dailyStats.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className={`p-6 border rounded-2xl ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex items-center justify-between mb-4">
              <h4 className={`font-bold ${darkMode ? 'text-slate-50' : 'text-slate-900'}`}>Ostatnie dni</h4>
              <span className="text-[10px] text-slate-400">Ostatnie 5 wpisów</span>
            </div>
            <div className="space-y-3">
              {dailyStats.slice(-5).reverse().map((day, idx) => (
                <div key={idx} className="flex items-center justify-between gap-4 text-xs text-slate-500">
                  <span>{new Date(day.date).toLocaleDateString('pl-PL', { day: '2-digit', month: '2-digit' })}</span>
                  <span className="font-semibold text-slate-900 dark:text-slate-100">{day.views.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
          <div className={`p-6 border rounded-2xl ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex items-center justify-between mb-4">
              <h4 className={`font-bold ${darkMode ? 'text-slate-50' : 'text-slate-900'}`}>Wskaźnik zaangażowania</h4>
              <span className="text-[10px] text-slate-400">Wskaźnik</span>
            </div>
            <p className={`text-sm ${darkMode ? 'text-slate-300' : 'text-slate-500'}`}>
              W ostatnim okresie wizytówka zanotowała <span className={`font-bold ${comparison.change >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>{comparison.change >= 0 ? 'wzrost' : 'spadek'}</span>.
            </p>
            <div className="mt-4 rounded-3xl overflow-hidden bg-slate-100 dark:bg-slate-800">
              <div className="grid grid-cols-2 gap-2 p-3 text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 bg-slate-200 dark:bg-slate-900">
                <span>Metryka</span>
                <span className="text-right">Wartość</span>
              </div>
              <div className="space-y-2 p-4">
                <div className="flex items-center justify-between text-sm text-slate-700 dark:text-slate-200">
                  <span>Średnia dzienna</span>
                  <span>{Math.round(dailyStats.reduce((acc, cur) => acc + cur.views, 0) / dailyStats.length).toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-sm text-slate-700 dark:text-slate-200">
                  <span>Najlepszy dzień</span>
                  <span>{Math.max(...dailyStats.map((d) => d.views)).toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-sm text-slate-700 dark:text-slate-200">
                  <span>Łącznie wyświetleń</span>
                  <span>{dailyStats.reduce((acc, cur) => acc + cur.views, 0).toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ✨ Trend Forecast Section */}
      {forecast && (
        <div className={`p-6 border rounded-2xl ${
          darkMode 
            ? 'bg-slate-900 border-slate-800' 
            : 'bg-indigo-50/50 border-indigo-200/50'
        }`}>
          <div className="flex items-center justify-between cursor-pointer" onClick={() => setShowTrendForecast(!showTrendForecast)}>
            <h4 className={`font-bold text-sm flex items-center gap-2 ${darkMode ? 'text-slate-50' : 'text-slate-900'}`}>
              <Zap className="w-4 h-4 text-indigo-600" />
              <span>Prognoza trendu AI</span>
            </h4>
            <TrendingUp className={`w-5 h-5 transition-transform ${showTrendForecast ? 'rotate-180' : ''} ${darkMode ? 'text-slate-400' : 'text-slate-500'}`} />
          </div>
          
          {showTrendForecast && (
            <div className={`mt-4 p-4 rounded-xl border ${
              darkMode 
                ? 'bg-slate-800 border-slate-700' 
                : 'bg-white border-indigo-100'
            }`}>
              <p className={`text-xs font-semibold leading-relaxed ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                Na podstawie ostatnich 7 dni, prognozujemy <span className="font-bold text-indigo-600">{forecast.nextWeekViews} wyświetleń</span> w ciągu następnego tygodnia.
                Trend jest <span className={`font-bold ${forecast.trend === 'up' ? 'text-emerald-600' : 'text-red-600'}`}>{forecast.trend === 'up' ? 'wzrostowy' : 'spadkowy'}</span> ({forecast.percentage}%).
              </p>
            </div>
          )}
        </div>
      )}

      {/* Loading State */}
      {loading && (
        <div className={`p-4 rounded-xl border animate-pulse ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
          <div className="h-4 bg-gradient-to-r from-indigo-500 to-transparent rounded w-3/4"></div>
        </div>
      )}

      {/* Empty State - No Statistics Yet */}
      {!loading && dailyStats.length === 0 && (
        <div className={`p-12 rounded-2xl border-2 border-dashed text-center ${darkMode ? 'bg-slate-900/50 border-slate-700' : 'bg-slate-50/50 border-slate-200'}`}>
          <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full mb-4 ${darkMode ? 'bg-slate-800' : 'bg-slate-100'}`}>
            <BarChart3 className={`w-6 h-6 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`} />
          </div>
          <h4 className={`font-bold text-sm mb-1 ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>Brak danych statystyk</h4>
          <p className={`text-xs mb-4 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Twoja wizytówka dopiero się uaktywnia. Statystyki pojawią się tutaj, gdy klienci zaczną przeglądać Twoją ofertę i wchodzić w interakcje.</p>
          <p className={`text-[11px] font-semibold ${darkMode ? 'text-slate-500' : 'text-slate-600'}`}>💡 Porada: Uzupełnij wszystkie dane profilu, aby zwiększyć widoczność w wyszukiwarce.</p>
        </div>
      )}

      {/* Keywords & Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 border-t pt-8" style={{ borderColor: darkMode ? '#1e293b' : '#e2e8f0' }}>
        <div className={`border rounded-2xl p-6 ${
          darkMode 
            ? 'bg-slate-900 border-slate-800' 
            : 'bg-slate-50/50 border-slate-200/50'
        }`}>
          <h4 className={`font-bold text-sm mb-4 flex items-center gap-2 ${darkMode ? 'text-slate-50' : 'text-slate-900'}`}>
            <TrendingUp className={`w-4 h-4 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`} />
            <span>Najpopularniejsze słowa kluczowe</span>
          </h4>
          <div className="space-y-2">
            {(company.services?.split(',').map(s => s.trim()).filter(Boolean).slice(0, 4) || []).map((kw, index) => (
              <div key={index} className={`flex justify-between items-center py-2.5 px-4 rounded-xl border ${
                darkMode
                  ? 'bg-slate-800 border-slate-700 hover:bg-slate-700'
                  : 'bg-white border-slate-200/40 shadow-2xs hover:shadow-md'
              }`}>
                <span className={`text-xs font-semibold ${darkMode ? 'text-slate-200' : 'text-slate-800'}`}>{index + 1}. {kw} ({company.city || 'Gniezno'})</span>
                <span className={`text-[9px] font-bold px-2 py-0.5 rounded ${darkMode ? 'bg-indigo-950 text-indigo-400' : 'bg-indigo-50 text-indigo-600 border border-indigo-100/50'}`}>Wysoki CTR</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recommendations */}
        <div className={`border rounded-2xl p-6 ${
          darkMode 
            ? 'bg-slate-900 border-slate-800' 
            : 'bg-slate-50/50 border-slate-200/50'
        }`}>
          <h4 className={`font-bold text-sm mb-4 flex items-center gap-2 ${darkMode ? 'text-slate-50' : 'text-slate-900'}`}>
            <Sparkles className={`w-4 h-4 ${darkMode ? 'text-indigo-400' : 'text-indigo-500'}`} />
            <span>Zalecenia podnoszące pozycję AI</span>
          </h4>
          <div className="space-y-2">
            {completenessItems.map((item, index) => (
              <div key={index} className={`flex items-center justify-between p-3 rounded-xl border ${
                darkMode
                  ? 'bg-slate-800 border-slate-700'
                  : 'bg-white border-slate-200/20'
              }`}>
                <div className="flex items-center gap-2.5 min-w-0">
                  {item.done ? (
                    <CheckCircle2 className={`w-4 h-4 shrink-0 ${darkMode ? 'text-emerald-400' : 'text-emerald-500'}`} />
                  ) : (
                    <AlertCircle className={`w-4 h-4 shrink-0 ${darkMode ? 'text-amber-400' : 'text-amber-500'}`} />
                  )}
                  <span className={`text-xs font-semibold truncate ${item.done ? darkMode ? 'text-slate-400 line-through' : 'text-slate-400 line-through' : darkMode ? 'text-slate-200' : 'text-slate-800'}`}>
                    {item.label}
                  </span>
                </div>
                <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded leading-none shrink-0 ${
                  item.done ? darkMode ? 'bg-slate-700 text-slate-400' : 'bg-slate-100 text-slate-400' : darkMode ? 'bg-indigo-950 text-indigo-400 border border-indigo-900/50' : 'bg-indigo-50 text-indigo-600 border border-indigo-100/50'
                }`}>
                  {item.done ? 'Gotowe' : '+15 pkt AI'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
