import React, { useState, useEffect } from 'react';
import { Booking } from '@/types';
import { subscribeUserBookings, updateBookingStatus } from '../../lib/BookingEngine';
import { Calendar as CalendarIcon, Clock, Phone, User, Check, X, CheckCircle2, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { addToast } from '../ui/feedback/Toast';

interface CompanyBookingsManagerProps {
  companyId: string;
  companyName: string;
}

export function CompanyBookingsManager({ companyId, companyName }: CompanyBookingsManagerProps) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'accepted' | 'completed' | 'cancelled'>('all');

  useEffect(() => {
    if (!companyId) return;
    const unsub = subscribeUserBookings(companyId, true, (list) => {
      setBookings(list);
      setLoading(false);
    });
    return () => unsub();
  }, [companyId]);

  const handleStatusChange = async (booking: Booking, newStatus: Booking['status']) => {
    try {
      await updateBookingStatus(
        booking.id,
        newStatus,
        booking.clientId,
        booking.serviceName,
        booking.date,
        booking.startTime
      );
      if (newStatus === 'accepted') addToast(`Zaakceptowano wizytę dla klienta ${booking.clientName}`, 'success');
      else if (newStatus === 'completed') addToast(`Oznaczono wizytę jako zakończoną!`, 'success');
      else if (newStatus === 'cancelled') addToast(`Anulowano wizytę.`, 'info');
    } catch (err) {
      console.error('Error updating status:', err);
      addToast('Wystąpił błąd przy zmianie statusu.', 'error');
    }
  };

  const filteredBookings = bookings.filter(b => {
    if (statusFilter === 'all') return true;
    return b.status === statusFilter;
  });

  const getStatusBadge = (status: Booking['status']) => {
    switch (status) {
      case 'accepted':
        return <span className="px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold rounded-lg text-xs border border-emerald-200 dark:border-emerald-800">Zaakceptowana</span>;
      case 'pending':
        return <span className="px-2.5 py-1 bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 font-bold rounded-lg text-xs border border-amber-200 dark:border-amber-800">Oczekująca</span>;
      case 'completed':
        return <span className="px-2.5 py-1 bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-bold rounded-lg text-xs border border-blue-200 dark:border-blue-800">Zakończona</span>;
      case 'cancelled':
        return <span className="px-2.5 py-1 bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 font-bold rounded-lg text-xs border border-rose-200 dark:border-rose-800">Anulowana</span>;
    }
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700 space-y-6 font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-700 pb-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">Zarządzanie Rezerwacjami Wizyt</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Zarządzaj harmonogramem i zatwierdzaj wizyty od klientów w czasie rzeczywistym
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-1.5 text-xs">
          {(['all', 'pending', 'accepted', 'completed', 'cancelled'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl font-bold capitalize transition-colors cursor-pointer ${
                statusFilter === st
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
              }`}
            >
              {st === 'all' ? 'Wszystkie' : st === 'pending' ? 'Oczekujące' : st === 'accepted' ? 'Zaakceptowane' : st === 'completed' ? 'Zakończone' : 'Anulowane'}
            </button>
          ))}
        </div>
      </div>

      {/* Bookings List */}
      {loading ? (
        <div className="py-8 text-center text-xs text-slate-400 animate-pulse">Ładowanie listy rezerwacji...</div>
      ) : filteredBookings.length === 0 ? (
        <div className="py-12 text-center bg-slate-50 dark:bg-slate-900/40 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-700">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full mb-4 bg-white dark:bg-slate-800">
            <CalendarIcon className="w-6 h-6 text-slate-400" />
          </div>
          <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-1">Brak rezerwacji</h4>
          <p className="text-xs text-slate-500 dark:text-slate-400">Nowe wizyty będą pojawiać się tutaj w czasie rzeczywistym</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredBookings.map(b => (
            <div key={b.id} className="p-4 bg-slate-50/50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-700/80 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-3">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">{b.clientName}</span>
                  {getStatusBadge(b.status)}
                </div>
                <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                  Usługa: {b.serviceName} ({b.servicePrice} zł)
                </p>
                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400 pt-0.5">
                  <span className="flex items-center gap-1"><CalendarIcon className="w-3.5 h-3.5 text-indigo-400" /> {b.date}</span>
                  <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5 text-indigo-400" /> {b.startTime} - {b.endTime}</span>
                  <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5 text-indigo-400" /> {b.clientPhone}</span>
                </div>
                {b.notes && (
                  <p className="text-xs text-slate-600 dark:text-slate-300 italic pt-1">
                    Uwagi: "{b.notes}"
                  </p>
                )}
              </div>

              {/* Status Action Buttons */}
              <div className="flex items-center gap-2">
                {b.status === 'pending' && (
                  <>
                    <button
                      onClick={() => handleStatusChange(b, 'accepted')}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-sm"
                    >
                      <Check className="w-3.5 h-3.5" /> Akceptuj
                    </button>
                    <button
                      onClick={() => handleStatusChange(b, 'cancelled')}
                      className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-sm"
                    >
                      <X className="w-3.5 h-3.5" /> Odrzuć
                    </button>
                  </>
                )}

                {b.status === 'accepted' && (
                  <>
                    <button
                      onClick={() => handleStatusChange(b, 'completed')}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-sm"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> Zakończona
                    </button>
                    <button
                      onClick={() => handleStatusChange(b, 'cancelled')}
                      className="px-3.5 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold hover:bg-slate-300 transition-colors cursor-pointer"
                    >
                      Anuluj
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
